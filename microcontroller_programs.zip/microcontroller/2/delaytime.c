#include "stm32f4xx.h"

void timedelay(int n)
{
		int i;
		for(;n>0;n--)
		for(i=0;i<1024;i++);
}
