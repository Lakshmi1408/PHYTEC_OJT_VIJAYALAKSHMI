
void Enable(void);
void ledblink(void);
void pushbutton(void);
void led_on(void);
void led_off(void);
void timedelay(int n);

#define  PERIPH_BASE		    (0x40000000UL)
#define  AHB1PERIPH_OFFSET   (0x00020000UL)
#define  AHB1PERIPH_BASE     (PERIPH_BASE + AHB1PERIPH_OFFSET)
#define  GPIOA_OFFSET	    (0x0000UL)
#define  GPIOA_BASE			(AHB1PERIPH_BASE + GPIOA_OFFSET)
#define  RCC_OFFSET			(0x3800UL)
#define  RCC_BASE			(AHB1PERIPH_BASE +RCC_OFFSET)
#define AHB1EN_R_OFFSET		(0x30UL)
#define RCC_AHB1EN_R		(*(volatile unsigned int*)(RCC_BASE +AHB1EN_R_OFFSET))
#define MODER_OFFSET		(0x00UL)
#define GPIOA_MODER			(*(volatile unsigned int*)(RCC_BASE + MODER_OFFSET))
#define ODR_OFFSET			(0x014UL)
#define GPIOA_ODR			(*(volatile unsigned int*)(RCC_BASE + ODR_OFFSET))
#define GPIOA_EN			(1U<<0)
#define PA5_MOD				(1U<<10)
#define LED_PIN				PA5_MOD
