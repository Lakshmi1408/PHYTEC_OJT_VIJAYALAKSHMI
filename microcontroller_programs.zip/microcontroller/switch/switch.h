void enab(void);
void cond(void);
