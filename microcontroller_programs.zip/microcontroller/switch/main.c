#include"switch.h"
int main(void) {
	enab();

while(1) {
	cond();
 /* turn on green LED */
}
}
