#include "stm32f4xx.h"

void Enable(void)
{
	RCC->AHB1ENR|=1;
	RCC->AHB1ENR|=4;
}
void ledblink(void)
{
	GPIOA->MODER &= ~0x00000C00;
	GPIOA->MODER |=0x00000400;
	GPIOC->MODER &= ~0x0C000000;
}
void pushbutton(void)
{
	if (GPIOC->IDR & 0x2000)
		GPIOA->BSRR=0x00200000;
	else
		GPIOA->BSRR=0x00000020;
}
