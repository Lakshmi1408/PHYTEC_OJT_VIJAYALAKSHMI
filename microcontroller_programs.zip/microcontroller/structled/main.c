#include "struct.h"

int main()
{
	Enable();
	ledblink();

	while(1)
	{
		pushbutton();
	}
}
