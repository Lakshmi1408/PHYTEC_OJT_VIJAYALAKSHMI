void Enable(void);
void ledblink(void);
void pushbutton(void);
#include<stdint.h>

#define _IO volatile
#define PERIPH_BASE            0x40000000
#define AHB1PERIPH_OFFSET      0x20000
#define AHB1_BASE              (PERIPH_BASE+AHB1PERIPH_OFFSET)
#define GPIOA_OFFSET           0x00000000
#define GPIOA_BASE             (AHB1_BASE+GPIOA_OFFSET)
#define GPIOC_OFFSET           0x00000800
#define GPIOC_BASE             (AHB1_BASE+GPIOC_OFFSET)
#define RCC_OFFSET             0x3800
#define RCC_BASE               (AHB1_BASE+RCC_OFFSET)

 typedef struct
{
  _IO uint32_t MODER;
  _IO uint32_t dummy[3];
  _IO unit32_t IDR;
  _IO uint32_t ODR;
  _IO unit32_t BSRR;
} GPIO_TypeDef;

 typedef struct
{
	_IO unit32_t dummy[12];
	_IO unit32_t AHB1ENR;
}RCC_TypeDef;

#define GPIOA  ((GPIO_TypeDef*)(GPIOA_BASE))
#define GPIOC  ((GPIO_TypeDef*)(GPIOC_BASE))
#define RCC    ((GPIO_TypeDef*)(RCC_BASE))
