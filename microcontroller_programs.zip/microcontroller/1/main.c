#include "switch.h"

int main()
{
	Enable();
	ledblink();

	while(1)
	{
		pushbutton();
	}
}
