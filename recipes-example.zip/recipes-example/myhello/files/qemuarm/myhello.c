#include<stdioo.h>
int main()
{
	printf("hello qemuarm\n");
	return 0;
}
